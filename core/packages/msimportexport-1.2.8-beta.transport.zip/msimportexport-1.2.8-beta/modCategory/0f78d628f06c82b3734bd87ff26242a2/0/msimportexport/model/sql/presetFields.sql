INSERT INTO `modx_msie_presets_fields` (`id`, `name`, `type`, `act`, `fields`) VALUES
(1, 'export', 'products', 2, '["id","pagetitle","article"]');