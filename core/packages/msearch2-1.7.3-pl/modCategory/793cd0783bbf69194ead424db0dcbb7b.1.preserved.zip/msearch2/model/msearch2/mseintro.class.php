<?php
class mseIntro extends xPDOObject {}