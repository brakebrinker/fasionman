<?php

class msImportExportResourceCreateProcessor extends modResourceCreateProcessor {

}
return 'msImportExportResourceCreateProcessor';
