<?php
class MsieHeadAlias extends xPDOSimpleObject {}