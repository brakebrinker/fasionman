<?php
class msImportExportUpdateProcessor extends modObjectUpdateProcessor {
    public $languageTopics = array('msimportexport:default');
    public $classKey = 'MsieHeadAlias';
}
return 'msImportExportUpdateProcessor';