<?php
class  msImportExportCreateProcessor extends modObjectCreateProcessor {
    public $classKey = 'MsieHeadAlias';
    public $languageTopics = array('msimportexport:default');
}
return 'msImportExportCreateProcessor';