<?php
require_once (dirname(dirname(__FILE__)) . '/msorder.class.php');
class msOrder_mysql extends msOrder {}