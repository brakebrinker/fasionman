<?php
require_once (dirname(dirname(__FILE__)) . '/mseword.class.php');
class mseWord_mysql extends mseWord {}