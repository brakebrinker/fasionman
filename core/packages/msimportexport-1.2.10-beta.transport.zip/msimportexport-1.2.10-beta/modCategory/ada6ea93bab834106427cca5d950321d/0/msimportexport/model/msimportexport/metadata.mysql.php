<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'MsieHeadAlias',
    1 => 'MsiePresetsFields',
  ),
);